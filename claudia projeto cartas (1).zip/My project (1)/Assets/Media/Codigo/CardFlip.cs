using UnityEngine;
using System.Collections; // Necess�rio para usar as Coroutines

public class CardFlip : MonoBehaviour
{
    // Vari�vel para controlar a dura��o da anima��o (em segundos)
    public float flipDuration = 0.35f;

    // Vari�vel para evitar que a anima��o seja interrompida por cliques repetidos
    private bool isAnimating = false;

    void Update()
    {
        // 1. Verifica se a Barra de Espa�o (KeyCode.Space) foi pressionada
        // 2. Garante que a carta n�o est� no meio de outra anima��o
        if (Input.GetKeyDown(KeyCode.Space) && !isAnimating)
        {
            // Inicia a fun��o de anima��o
            StartCoroutine(FlipAnimation());
        }
    }

    private IEnumerator FlipAnimation()
    {
        isAnimating = true; // Bloqueia novos flips

        // Define as rota��es de in�cio e fim da anima��o
        Quaternion startRotation = transform.rotation;

        // A rota��o final ser� a rota��o atual + 180 graus no eixo Y.
        // Isso garante que a carta sempre vire, n�o importa a posi��o inicial.
        Quaternion endRotation = startRotation * Quaternion.Euler(180, 360f, 0);

        float elapsedTime = 0f;

        // Loop de anima��o: roda a cada frame
        while (elapsedTime < flipDuration)
        {
            // Interpola��o de Rota��o Suave (Slerp)
            // Move a rota��o gradualmente do in�cio para o fim
            transform.rotation = Quaternion.Slerp(
                startRotation,
                endRotation,
                elapsedTime / flipDuration // O fator de 0 a 1 (progresso)
            );

            elapsedTime += Time.deltaTime; // Incrementa o tempo

            yield return null; // Pausa e continua no pr�ximo frame
        }

        // Garante que a rota��o finalize exatamente no �ngulo de 180/360 graus.
        transform.rotation = endRotation;

        isAnimating = false; // Desbloqueia a carta para um novo flip
    }
}